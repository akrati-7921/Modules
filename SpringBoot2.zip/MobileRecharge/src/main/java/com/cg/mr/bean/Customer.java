package com.cg.mr.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.GenericGenerator;

@Entity
public class Customer 
{
	@Id
	//@GeneratedValue(generator = "uuid")
	//@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name="mobileno",length=15,unique=true)
	
	private String mobileNo;
	@Column(name="fname",length=20)
	private String fname;
	@Column(name="lname",length=20)
	private String lname;
	@Column(name="age",length=5)
	private int age;
	@Column(name="balance",length=10)
	private double balanace;
	public Customer() 
	{
		
	}
	public Customer(String mobileNo, String fname, String lname, int age,double balance) {
		super();
		this.mobileNo = mobileNo;
		this.fname = fname;
		this.lname = lname;
		this.age = age;
		this.balanace=balance;
		
	}
	public String getMobileNo() 
	{
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) 
	{
		this.mobileNo = mobileNo;
	}
	public String getFname() 
	{
		return fname;
	}
	public void setFname(String fname) 
	{
		this.fname = fname;
	}
	public String getLname()
	{
		return lname;
	}
	public void setLname(String lname) 
	{
		this.lname = lname;
	}
	public int getAge() 
	{
		return age;
	}
	public void setAge(int age) 
	{
		this.age = age;
	}
	
	public double getBalanace() 
	{
		return balanace;
	}
	public void setBalanace(double balanace) 
	{
		this.balanace = balanace;
	}
	
	@Override
	public String toString() 
	{
		return "Customer [mobileNo=" + mobileNo + ", fname=" + fname + ", lname=" + lname + ", age=" + age
				+ ", balanace=" + balanace + "]";
	}
	
	

}
