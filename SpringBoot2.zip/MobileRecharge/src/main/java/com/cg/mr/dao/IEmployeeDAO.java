package com.cg.mr.dao;

import org.springframework.stereotype.Repository;

import com.cg.mr.bean.Customer;
@Repository
public interface IEmployeeDAO 
{
	public String createCustomer(Customer customer);
	public String Recharge(String mobileno,double amount);
	public Customer showCustomer(String mobileno);

}
