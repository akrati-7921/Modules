package com.cg.capstore.services;

import com.cg.capstore.beans.Feedback;

public interface FeedbackService {

	public String addfeedback(Feedback fee);
}
