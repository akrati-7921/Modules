package com.cg.pcms.exception;

public class IdNotMatch extends RuntimeException{

}
