package com.cg.pcms.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.pcms.bean.Product;
import com.cg.pcms.exception.IdNotFound;
import com.cg.pcms.exception.IdNotMatch;

@Repository
@Transactional
public class ProductDAOImpl implements IProductDAO{
	
	@PersistenceContext
	private EntityManager entityManager;

	//------------------------ 1. Products Cart Management --------------------------
	/*******************************************************************************************************
	 - Function Name	:	findAllProducts() 
	 - Input Parameters	:   ---------------------
	 - Return Type		:	List<Product>
	 - Throws			:  	---------------------
	 - Author			:	Akrati Agrawal
	 - Creation Date	:	12/03/2019
	 - Description		:	List all product from database
	 ********************************************************************************************************/

	@Override
	@Transactional
	public List<Product> findAllProducts() {
		TypedQuery<Product> query=entityManager.createQuery("select prod from Product prod ", Product.class);	
		List<Product> list= query.getResultList();
		return list;
		
	}

	//------------------------ 1. Products Cart Management --------------------------
			/*******************************************************************************************************
			 - Function Name	:	createProduct(Product product)
			 - Input Parameters	:   Product product
			 - Return Type		:	Product
			 - Throws			:  	---------------------
			 - Author			:	Akrati Agrawal
			 - Creation Date	:	12/03/2019
			 - Description		:	Add product into database
			 ********************************************************************************************************/
	
	@Override
	@Transactional
	public Product createProduct(Product product) {
		 entityManager.persist(product);
		 return product;
	}

	//------------------------ 1. Products Cart Management --------------------------
	/*******************************************************************************************************
	 - Function Name	:	getProductById(String id)
	 - Input Parameters	:   String id
	 - Return Type		:	Product
	 - Throw			:  	IdNotFound()
	 - Author			:	Akrati Agrawal
	 - Creation Date	:	12/03/2019
	 - Description		:	Get product from database using id
	 ********************************************************************************************************/
	
	@Override
	@Transactional
	public Product getProductById(String id) {
		Product product= entityManager.find(Product.class, id);
		if(product==null)
		{
			throw new IdNotFound();
		}
		return product;
	}

	//------------------------ 1. Products Cart Management --------------------------
		/*******************************************************************************************************
		 - Function Name	:	updateProduct(String id,Product product) 
		 - Input Parameters	:   String id,Product product
		 - Return Type		:	Product
		 - Throw			:  	IdNotMatch
		 - Author			:	Akrati Agrawal
		 - Creation Date	:	12/03/2019
		 - Description		:	Update product into database
		 ********************************************************************************************************/
	
	@Override
	@Transactional
	public Product updateProduct(String id,Product product) {
		if(!(id.equals(product.getId())))
		{
			throw new IdNotMatch();
		}
		
		entityManager.merge(product);
		entityManager.flush();
		return product;
	}

	//------------------------ 1. Products Cart Management --------------------------
	/*******************************************************************************************************
	 - Function Name	:	deleteProduct(String id) 
	 - Input Parameters	:   String id
	 - Return Type		:	Product
	 - Throw			:  	IdNotFound()
	 - Author			:	Akrati Agrawal
	 - Creation Date	:	12/03/2019
	 - Description		:	Delete product from database
	 ********************************************************************************************************/
	
	@Override
	@Transactional
	public Product deleteProduct(String id) {
		Product product= entityManager.find(Product.class, id);
		if(product==null)
		{
			throw new IdNotFound();
		}
		entityManager.remove(product);
		entityManager.flush();
		return product;
		 
	}
	
}
