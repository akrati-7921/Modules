package com.cg.pcms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.pcms.bean.Product;
import com.cg.pcms.dao.ProductDAOImpl;

@Service
public class ProductServiceImpl implements IProductService {
	
	@Autowired(required=true)
	ProductDAOImpl productDAO;
	
	//------------------------ 1. Products Cart Management --------------------------
		/*******************************************************************************************************
		 - Function Name	:	findAllProducts() 
		 - Input Parameters	:   ---------------------
		 - Return Type		:	List<Product>
		 - Throws			:  	---------------------
		 - Author			:	Akrati Agrawal
		 - Creation Date	:	12/03/2019
		 - Description		:	List all product from database
		 ********************************************************************************************************/
	
	public List<Product> findAllProducts(){
		return productDAO.findAllProducts() ;	
	}
	
	//------------------------ 1. Products Cart Management --------------------------
	/*******************************************************************************************************
	 - Function Name	:	createProduct(Product product)
	 - Input Parameters	:   Product product
	 - Return Type		:	Product
	 - Throws			:  	---------------------
	 - Author			:	Akrati Agrawal
	 - Creation Date	:	12/03/2019
	 - Description		:	Add product into database
	 ********************************************************************************************************/
	
	public Product createProduct(Product product) {
		return productDAO.createProduct(product);
	}
	
	//------------------------ 1. Products Cart Management --------------------------
		/*******************************************************************************************************
		 - Function Name	:	getProductById(String id)
		 - Input Parameters	:   String id
		 - Return Type		:	Product
		 - Throw			:  	IdNotFound()
		 - Author			:	Akrati Agrawal
		 - Creation Date	:	12/03/2019
		 - Description		:	Get product from database using id
		 ********************************************************************************************************/
	
	public Product getProductById(String id) {
		return productDAO.getProductById(id);
	}
	
	//------------------------ 1. Products Cart Management --------------------------
			/*******************************************************************************************************
			 - Function Name	:	updateProduct(String id,Product product) 
			 - Input Parameters	:   String id,Product product
			 - Return Type		:	Product
			 - Throw			:  	IdNotMatch
			 - Author			:	Akrati Agrawal
			 - Creation Date	:	12/03/2019
			 - Description		:	Update product into database
			 ********************************************************************************************************/
	public Product updateProduct(String id, Product product) {
		return productDAO.updateProduct(id,product);
		
	}
	
	//------------------------ 1. Products Cart Management --------------------------
		/*******************************************************************************************************
		 - Function Name	:	deleteProduct(String id) 
		 - Input Parameters	:   String id
		 - Return Type		:	Product
		 - Throw			:  	IdNotFound()
		 - Author			:	Akrati Agrawal
		 - Creation Date	:	12/03/2019
		 - Description		:	Delete product from database
		 ********************************************************************************************************/
	
	public Product deleteProduct(String id) {
		return productDAO.deleteProduct(id);	
	}
}
