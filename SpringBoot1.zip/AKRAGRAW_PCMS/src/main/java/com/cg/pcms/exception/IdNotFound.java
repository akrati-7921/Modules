package com.cg.pcms.exception;

public class IdNotFound extends RuntimeException{

}
