package com.cg.pcms.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.pcms.bean.Product;
@Service
public interface IProductService {

	public List<Product> findAllProducts();
	public Product createProduct(Product product);
	public Product getProductById(String id);
	public Product updateProduct(String id,Product product);
	public Product deleteProduct(String id);
	
}
