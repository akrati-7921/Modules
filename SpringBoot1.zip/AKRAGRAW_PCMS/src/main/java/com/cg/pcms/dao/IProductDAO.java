package com.cg.pcms.dao;

import java.util.List;

import com.cg.pcms.bean.Product;

public interface IProductDAO {

	public List<Product> findAllProducts();
	public Product createProduct(Product product);
	public Product getProductById(String id);
	public Product updateProduct(String id,Product product);
	public Product deleteProduct(String id);
}
