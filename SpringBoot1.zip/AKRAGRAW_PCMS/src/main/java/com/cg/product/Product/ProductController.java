package com.cg.product.Product;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import com.cg.pcms.bean.Product;
import com.cg.pcms.exception.IdNotFound;
import com.cg.pcms.exception.IdNotMatch;
import com.cg.pcms.service.IProductService;

@RestController
public class ProductController {

	@Autowired(required=true)
	private IProductService service;
	
	@RequestMapping(method=RequestMethod.GET,value="product")
	public List<Product> findAllProducts(){
	return service.findAllProducts();
	}
	
	@RequestMapping(method=RequestMethod.POST,value="product")
	public Product createProduct(@RequestBody Product product) {
	return service.createProduct(product);
	}
	
	@RequestMapping(method=RequestMethod.GET,value="/product/{id}")
	public Product getProductById(@PathVariable String id) {
	return service.getProductById(id);
	}
	
	@RequestMapping(method=RequestMethod.PUT,value="/product/{id}")
	public Product updateProduct(@PathVariable String id,@RequestBody Product product) {
	return service.updateProduct(id,product);
	}
	
	@RequestMapping(method=RequestMethod.DELETE,value="/product/{id}")
	public Product deleteProduct(@PathVariable String id) {
	return service.deleteProduct(id);
	}	
	
	@ResponseStatus(value=HttpStatus.NOT_FOUND, reason="Product Id not present")
	@ExceptionHandler({IdNotFound.class})
	public void handleIdException()
	{
		
	}
	
	@ResponseStatus(value=HttpStatus.NOT_FOUND, reason="Product Id does not match with the Database id")
	@ExceptionHandler({IdNotMatch.class})
	public void handleIdMatchException()
	{
		
	}
}
