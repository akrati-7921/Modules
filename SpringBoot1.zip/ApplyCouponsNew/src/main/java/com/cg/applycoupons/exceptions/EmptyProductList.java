package com.cg.applycoupons.exceptions;

public class EmptyProductList extends RuntimeException {


	public EmptyProductList(String message) {
		// TODO Auto-generated constructor stub
	}
}
