package com.example.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.bean.AccountHolder;
import com.example.bean.Transactions;
import com.example.service.IAccountService;

@RestController
public class ControllerRest {

	
	@Autowired
	IAccountService service;
	
	@RequestMapping(value="/createAccount",method=RequestMethod.POST)
	public String createAccount(@RequestBody AccountHolder account) {
		
		return service.createAccount(account);
		
		
	}
	
	@RequestMapping(value="/deposit",method=RequestMethod.POST)
	public AccountHolder deposit(@RequestParam("mobile") String mobile,@RequestParam("amount") double amount) {
		return service.depositAmount(mobile, amount);
	}
	
	
	@RequestMapping(value="/withdraw",method=RequestMethod.POST)
	public AccountHolder withdraw(@RequestParam("mobile") String mobile,@RequestParam("amount") double amount) {
		return service.withdrawAmount(mobile, amount);
	}
	
	@RequestMapping(value="/showBalance",method=RequestMethod.POST)
	public double showBalance(@RequestParam("mobile") String mobile) {
		return service.showBalance(mobile);
	}
	
	@RequestMapping(value="/printTransaction",method=RequestMethod.POST)
	public List<Transactions> printTransaction(@RequestParam("mobile") String mobile) {
		return service.printTtansaction(mobile);
	}
	
	
	@RequestMapping(value="/fundTransfer",method=RequestMethod.POST)
	public ArrayList<AccountHolder> fundTransfer(@RequestParam("source") String sourceMobile,@RequestParam("target") String targetMobile,@RequestParam("amount") double amount) {
		return service.fundTransfer(sourceMobile, targetMobile, amount);
	}
}
