package com.cg.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.stereotype.Service;

import com.cg.capstore.repo.IInviteFriendRepo;

@Service
public class InviteFriendServiceImpl implements IInviteFriendService{
	
	@Autowired
	private IInviteFriendRepo inviteFriendRepo;

	@Override
	public String inviteFriend(String mobileNo) {
		
		return inviteFriendRepo.inviteFriend(mobileNo);
	}

}
