package com.capgemini.RegisterMerchant.repo;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capgemini.RegisterMerchant.bean.Merchant;
import com.capgemini.RegisterMerchant.exception.MerchantAlreadyExist;


@Transactional
@Repository
public class MerchantRepository implements  IMerchantRepository{

	@PersistenceContext
	EntityManager entity;
	
	@Override
	public Merchant registerMerchant(Merchant merchant) throws MerchantAlreadyExist{
		entity.persist(merchant);
		return merchant;
	}

	@Override
	public Merchant findMerchantByMobileNo(String mobile_no) {
		Merchant merchant;
		merchant=entity.find(Merchant.class,mobile_no);
		return merchant;
	}

}
