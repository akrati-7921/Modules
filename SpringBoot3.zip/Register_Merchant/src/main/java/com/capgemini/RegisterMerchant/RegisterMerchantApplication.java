package com.capgemini.RegisterMerchant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegisterMerchantApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegisterMerchantApplication.class, args);
	}

}
