package com.capgemini.RegisterMerchant.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
public class Merchant {
	
	@NotNull(message="Merchant name can not be null")
	@Size(min = 2,  max = 20, message = "Enter valid name")
	private String merchant_name;
	
	@NotNull(message="Merchant email can not be null")
	//@Pattern(regexp = "/^\\w+@[a-zA-Z_]+?\\.[a-zA-Z]{2,3}$/", message = "Enter valid email id")
	private String email;
	
	@Id
	@NotNull(message="Merchant mobile number can not be null")
	@Pattern(regexp = "[789]{1}[0-9]{9}", message = "mobile should be of 10 digits and with 7,8 or 9")
	private String mobile_no;
	
	
	
	@NotNull(message="Merchant type can not be null")
	private String merchant_type;
	
	@NotNull(message="Merchant address can not be null")
	@Size(min = 4,  max = 20, message = "Enter valid address")
	private String merchant_address;
	

	@NotNull(message="Password can not be null")
	@Size(min = 8,  max = 15, message = "Password length should be greater than 8")
	private String password ;
	
	
	public String getMobile_no() {
		return mobile_no;
	}
	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}
	public String getMerchant_name() {
		return merchant_name;
	}
	public void setMerchant_name(String merchant_name) {
		this.merchant_name = merchant_name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getMerchant_type() {
		return merchant_type;
	}
	public void setMerchant_type(String merchant_type) {
		this.merchant_type = merchant_type;
	}
	public String getMerchant_address() {
		return merchant_address;
	}
	public void setMerchant_address(String merchant_address) {
		this.merchant_address = merchant_address;
	}
	@Override
	public String toString() {
		return "Merchant [mobile_no=" + mobile_no + ", merchant_name=" + merchant_name + ", email=" + email
				+ ", password=" + password + ", merchant_type=" + merchant_type + ", merchant_address="
				+ merchant_address + "]";
	}
	public Merchant(String mobile_no, String merchant_name, String email, String password, String merchant_type,
			String merchant_address) {
		super();
		this.mobile_no = mobile_no;
		this.merchant_name = merchant_name;
		this.email = email;
		this.password = password;
		this.merchant_type = merchant_type;
		this.merchant_address = merchant_address;
	}
	public Merchant() {
		super();
		// TODO Auto-generated constructor stub
	}

	
}
