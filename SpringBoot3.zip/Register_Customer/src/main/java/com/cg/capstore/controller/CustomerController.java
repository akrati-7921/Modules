package com.cg.capstore.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.capstore.bean.Address;
import com.cg.capstore.bean.Customer;
import com.cg.capstore.exception.CustomerAlreadyExist;
import com.cg.capstore.service.ICustomerService;

@Controller
public class CustomerController {

	@Autowired
	ICustomerService service;	
	String id;
	
	@RequestMapping(value="/")
	public String createProduct()  {
		return "maintenance";
	}
	
	@RequestMapping(value="/addresspage")
	public String addAddress(@Valid @ModelAttribute("customer") Customer customer) throws CustomerAlreadyExist  {
		
		 service.registerCustomer(customer);
		 id=customer.getCustomerMobileNo();
		 return "addresspage";
	}
	
	@RequestMapping(value="/success")
	public String registered(@Valid @ModelAttribute("address") Address address)  {
		System.out.println(address);
		 service.addAddress(address,id);
		 return "sucess";
	}
}
