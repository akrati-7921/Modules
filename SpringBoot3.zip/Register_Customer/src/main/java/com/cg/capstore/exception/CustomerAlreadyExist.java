package com.cg.capstore.exception;

public class CustomerAlreadyExist extends Exception {

	public CustomerAlreadyExist(String msg) {
		super(msg);
	}

}
