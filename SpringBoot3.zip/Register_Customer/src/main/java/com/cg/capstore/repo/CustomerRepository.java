package com.cg.capstore.repo;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;

import com.cg.capstore.bean.Address;
import com.cg.capstore.bean.Cart;
import com.cg.capstore.bean.Customer;
import com.cg.capstore.bean.WishList;

import oracle.net.aso.l;

@Transactional
@Repository("repo")
public class CustomerRepository implements  ICustomerRepository{

	@PersistenceContext
	EntityManager entity;
	
	@Override
	public Customer registerCustomer(Customer customer) {
		System.out.println(customer);
		Random random=new Random();
		String cartId="C#"+Integer.toString(random.nextInt(100));
		String wishlistId="W#"+Integer.toString(random.nextInt(100));
		
		Cart cart=new Cart();
		cart.setCartId(cartId);
		WishList wish=new WishList();
		wish.setWishlistId(wishlistId);
		
		customer.setCart(cart);
		customer.setWishlist(wish);
		
		customer.setActive(true);
		
		entity.persist(customer);
		
		System.out.println(customer);
		
		return customer;
	}

	@Override
	public Address addAddress(Address address,String id) {
		
		System.out.println(address);
		Random random=new Random();
		String addressId="A#"+Integer.toString(random.nextInt(100));
		address.setAddressId(addressId);
		
		List<Address> list=new ArrayList<>();
		list.add(address);
		
		
		Customer customer=entity.find(Customer.class,id);
		customer.setAdresses(list);
		System.out.println(customer.getCustomerMobileNo());
		
		address.setCustomerAddress(customer);
		entity.merge(customer);
		
		System.out.println(address.getAddressId());
		
		return address;
	}

	@Override
	public Customer findCustomerByMobileNo(String customer_mobile_no) {
		Customer customer;
		customer=entity.find(Customer.class,customer_mobile_no);
		return customer;
	}

}
