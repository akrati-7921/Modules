package com.cg.capstore.repo;

import com.cg.capstore.bean.Address;
import com.cg.capstore.bean.Customer;
import com.cg.capstore.bean.Merchant;

public interface ICustomerRepository {

	public Customer registerCustomer(Customer customer) ;
	public Address addAddress(Address address, String id);
	public Customer findCustomerByMobileNo(String customer_mobile_no);
}
