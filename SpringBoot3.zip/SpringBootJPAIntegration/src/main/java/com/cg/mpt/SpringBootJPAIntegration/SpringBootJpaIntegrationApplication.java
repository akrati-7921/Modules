package com.cg.mpt.SpringBootJPAIntegration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan("com.cg")
@SpringBootApplication
@EntityScan("com.cg.bean")
public class SpringBootJpaIntegrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJpaIntegrationApplication.class, args);
	}

}
