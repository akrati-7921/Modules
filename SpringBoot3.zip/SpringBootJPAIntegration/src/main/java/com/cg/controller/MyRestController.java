package com.cg.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import com.cg.bean.Customer;
import com.cg.exception.IdNotPresent;
import com.cg.service.ICustomerService;

@RestController
public class MyRestController {

	@Autowired
	ICustomerService service;
	
	/*@RequestMapping("/hello")
	public String hello()
	{
		return "Welcome";
	}
	
	@RequestMapping(value="/getEmployee",method=RequestMethod.GET,produces="application/json")
	public Employee getEmployeeDetails() {
		
		Employee emp=new Employee();
		emp.setFirstName("Akrati");
		emp.setLastName("Agrawal");
		emp.setMobileNo("7088559555");
		emp.setEmail("akrati@gmail.com");
		return emp;
	}
	
	@RequestMapping(value="/addEmployee",method=RequestMethod.POST)
	public String addEmployee(@RequestParam("fname")String firstName,@RequestParam("lname")String lastName,
			@RequestParam("mobno")String mobno,@RequestParam("email")String email) {
		
		Employee emp=new Employee();
		emp.setFirstName(firstName);
		emp.setLastName(lastName);
		emp.setMobileNo(mobno);
		emp.setEmail(email);
		
		return "Employee Added Successfully";
	}*/
	
	/*@RequestMapping(value="/addCustomer",method=RequestMethod.POST)
	public String addCustomer(@RequestParam("fname")String firstName,@RequestParam("lname")String lastName,
			@RequestParam("mobno")String mobno,@RequestParam("email")String email,@RequestParam("age")int age,
			@RequestParam("city")String city) {
		
		Customer customer=new Customer();
		customer.setFirstName(firstName);
		customer.setLastName(lastName);
		customer.setMobileNo(mobno);
		customer.setEmail(email);
		customer.setAge(age);
		customer.setCity(city);
		
		customer=service.addCustomer(customer);
		return "Employee Added Successfully";
	}*/
	
	@RequestMapping(value="/addCustomer",consumes="application/json",produces="application/json",method=RequestMethod.POST)
	public Customer addCustomer(@RequestBody Customer customer) {
		
		customer=service.addCustomer(customer);
		return customer;
	}
	
	@RequestMapping(value="/updateCustomer",consumes="application/json",produces="application/json",method=RequestMethod.POST)
	public Customer updateCustomer(@RequestBody Customer customer) {
		
		customer=service.updateCustomer(customer);
		return customer;
	}
	
	@RequestMapping(value="/deleteCustomer/{custid}",consumes="application/json",produces="application/json")
	public Customer deleteCustomer(@PathVariable int custid) {
		
		Customer customer=service.removeCustomer(custid);
		return customer;
	}
	
	@RequestMapping(value="/getCustomer/{custid}",produces="application/json")
	public Customer getCustomer(@PathVariable int custid)
	{
		Customer customer=service.findCustomer(custid);
		return customer;
	}
	
	@RequestMapping(value="/getCustomerList",produces="application/json")
	public List<Customer> getCustomerList()
	{
		List<Customer> customer=service.getCustomerList();
		return customer;
	}
	
	@ResponseStatus(value=HttpStatus.NOT_FOUND, reason="Customer Id noty present")
	@ExceptionHandler({IdNotPresent.class})
	public void handleException()
	{
		
	}
}
