package Runner;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import PageBean.PageBeanFactoryClass;
import PageBean.PageFactoryPayment;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef {

	private WebDriver driver;
	private PageBeanFactoryClass objPageBean;
	private PageFactoryPayment objPayment;
	
	@Before
	public void setUp()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\BDD Workspace\\AKRAGRAW_SETB\\Driver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	@Given("^User is on registration page$")
	public void user_is_on_registration_page() throws Throwable {
		
		objPageBean = new PageBeanFactoryClass(driver);
		driver.get("C:\\BDD Workspace\\AKRAGRAW_SETB\\Driver\\ConferenceRegistartion.html");
	}

	@Then("^check the title of the registration page$")
	public void check_the_title_of_the_registration_page() throws Throwable {
		
		String title=driver.getTitle();
		if(title.contentEquals("Conference Registartion")) 
			System.out.println("****** Title Matched*********");
		else 
			System.out.println("****** Title NOT Matched***************");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	}

	@When("^user leaves FirstName blank$")
	public void user_leaves_FirstName_blank() throws Throwable {
	    
		objPageBean.setPfFirstName(""); Thread.sleep(750);
	}

	@When("^clicks on the next$")
	public void clicks_on_the_next() throws Throwable {
	   
		objPageBean.setPfNext();
	}

	@Then("^display alert message for registration$")
	public void display_alert_message_for_registration() throws Throwable {
	   
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("*******************" + alertMessage);
	    driver.close();
	}

	@When("^user leaves LastName blank$")
	public void user_leaves_LastName_blank() throws Throwable {
	    
		objPageBean.setPfFirstName("Akrati"); Thread.sleep(750);
		objPageBean.setPfLastName(""); Thread.sleep(750);
	}

	@When("^user enters all data$")
	public void user_enters_all_data() throws Throwable {
		
		objPageBean.setPfFirstName("Akrati"); Thread.sleep(750);
		objPageBean.setPfLastName("Agrawal"); Thread.sleep(750);
	}

	@When("^user enters incorrect email format and clicks the next$")
	public void user_enters_incorrect_email_format_and_clicks_the_next() throws Throwable {
		
		objPageBean.setPfEmail("2a4@.com"); Thread.sleep(750);
		objPageBean.setPfNext(); Thread.sleep(750);
	}

	@When("^user leaves Contact blank and clicks on the next$")
	public void user_leaves_Contact_blank_and_clicks_on_the_next() throws Throwable {
		objPageBean.setPfFirstName("Akrati"); Thread.sleep(750);
		objPageBean.setPfLastName("Agrawal"); Thread.sleep(750);
		objPageBean.setPfEmail("akrati@gmail.com"); Thread.sleep(750);
		objPageBean.setPfPhone(""); Thread.sleep(750);
		objPageBean.setPfNext(); Thread.sleep(750);
	}

	@When("^user enters incorrect Contact format and clicks the next$")
	public void user_enters_incorrect_Contact_format_and_clicks_the_next() throws Throwable {
		objPageBean.setPfFirstName("Akrati"); Thread.sleep(750);
		objPageBean.setPfLastName("Agrawal"); Thread.sleep(750);
		objPageBean.setPfEmail("akrati@gmail.com"); Thread.sleep(750);
		objPageBean.setPfPhone("23456789"); Thread.sleep(750);
		objPageBean.setPfNext();
	}

	@When("^user does not select NumberOfPeople and clicks on the next$")
	public void user_does_not_select_NumberOfPeople_and_clicks_on_the_next() throws Throwable {
		
		objPageBean.setPfFirstName("Akrati"); Thread.sleep(750);
		objPageBean.setPfLastName("Agrawal"); Thread.sleep(750);
		objPageBean.setPfEmail("akrati@gmail.com"); Thread.sleep(750);
		objPageBean.setPfPhone("7088559555"); Thread.sleep(750);
		objPageBean.setPfNoOfPeople("1"); Thread.sleep(750);
		objPageBean.setPfNext(); Thread.sleep(750);
	}

	@When("^user leaves BuildingName and clicks on the next$")
	public void user_leaves_BuildingName_and_clicks_on_the_next() throws Throwable {
		
		objPageBean.setPfFirstName("Akrati"); Thread.sleep(750);
		objPageBean.setPfLastName("Agrawal"); Thread.sleep(750);
		objPageBean.setPfEmail("akrati@gmail.com"); Thread.sleep(750);
		objPageBean.setPfPhone("7088559555"); Thread.sleep(750);
		objPageBean.setPfNoOfPeople("2"); Thread.sleep(750);
		objPageBean.setPfBuilding(""); Thread.sleep(750);
		objPageBean.setPfNext(); Thread.sleep(750);
	}

	@When("^user leaves AreaName and clicks on the next$")
	public void user_leaves_AreaName_and_clicks_on_the_next() throws Throwable {
	
		objPageBean.setPfFirstName("Akrati"); Thread.sleep(750);
		objPageBean.setPfLastName("Agrawal"); Thread.sleep(750);
		objPageBean.setPfEmail("akrati@gmail.com"); Thread.sleep(750);
		objPageBean.setPfPhone("7088559555"); Thread.sleep(750);
		objPageBean.setPfNoOfPeople("2"); Thread.sleep(750);
		objPageBean.setPfBuilding("GLC"); Thread.sleep(750);
		objPageBean.setPfArea(""); Thread.sleep(750);
		objPageBean.setPfNext(); Thread.sleep(750);
	}

	@When("^user does not select City and clicks on the next$")
	public void user_does_not_select_City_and_clicks_on_the_next() throws Throwable {
		
		objPageBean.setPfFirstName("Akrati"); Thread.sleep(750);
		objPageBean.setPfLastName("Agrawal"); Thread.sleep(750);
		objPageBean.setPfEmail("akrati@gmail.com"); Thread.sleep(750);
		objPageBean.setPfPhone("7088559555"); Thread.sleep(750);
		objPageBean.setPfNoOfPeople("2"); Thread.sleep(750);
		objPageBean.setPfBuilding("GLC"); Thread.sleep(750);
		objPageBean.setPfArea("Talawade"); Thread.sleep(750);
		objPageBean.setPfCity("Select City"); Thread.sleep(750);
		objPageBean.setPfNext(); Thread.sleep(750);
	}

	@When("^user does not select State and clicks on the next$")
	public void user_does_not_select_State_and_clicks_on_the_next() throws Throwable {
	    
		objPageBean.setPfFirstName("Akrati"); Thread.sleep(750);
		objPageBean.setPfLastName("Agrawal"); Thread.sleep(750);
		objPageBean.setPfEmail("akrati@gmail.com"); Thread.sleep(750);
		objPageBean.setPfPhone("7088559555"); Thread.sleep(750);
		objPageBean.setPfNoOfPeople("2"); Thread.sleep(750);
		objPageBean.setPfBuilding("GLC"); Thread.sleep(750);
		objPageBean.setPfArea("Talawade"); Thread.sleep(750);
		objPageBean.setPfCity("Pune"); Thread.sleep(750);
		objPageBean.setPfState("Select State"); Thread.sleep(750);
		objPageBean.setPfNext(); Thread.sleep(750);
	}

	@When("^user does not select MemberStatus and clicks on the next$")
	public void user_does_not_select_MemberStatus_and_clicks_on_the_next() throws Throwable {
	   
		objPageBean.setPfFirstName("Akrati"); Thread.sleep(750);
		objPageBean.setPfLastName("Agrawal"); Thread.sleep(750);
		objPageBean.setPfEmail("akrati@gmail.com"); Thread.sleep(750);
		objPageBean.setPfPhone("7088559555"); Thread.sleep(750);
		objPageBean.setPfNoOfPeople("2"); Thread.sleep(750);
		objPageBean.setPfBuilding("GLC"); Thread.sleep(750);
		objPageBean.setPfArea("Talawade"); Thread.sleep(750);
		objPageBean.setPfCity("Pune"); Thread.sleep(750);
		objPageBean.setPfState("Maharashtra"); Thread.sleep(750);
		objPageBean.setPfMemberStatus(""); Thread.sleep(750);
		objPageBean.setPfNext(); Thread.sleep(750);
	}
	@When("^user enters all valid data and clicks on the next and display the alert box$")
	public void user_enters_all_valid_data_and_clicks_on_the_next_and_display_the_alert_box() throws Throwable {
		objPageBean.setPfFirstName("Akrati"); Thread.sleep(750);
		objPageBean.setPfLastName("Agrawal"); Thread.sleep(750);
		objPageBean.setPfEmail("akrati@gmail.com"); Thread.sleep(750);
		objPageBean.setPfPhone("7088559555"); Thread.sleep(750);
		objPageBean.setPfNoOfPeople("2"); Thread.sleep(750);
		objPageBean.setPfBuilding("GLC"); Thread.sleep(750);
		objPageBean.setPfArea("Talawade"); Thread.sleep(750);
		objPageBean.setPfCity("Pune"); Thread.sleep(750);
		objPageBean.setPfState("Maharashtra"); Thread.sleep(750);
		objPageBean.setPfMemberStatus("non-member"); Thread.sleep(750);
		objPageBean.setPfNext(); Thread.sleep(750);
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("*******************" + alertMessage);
	}

	@Then("^navigate to payment details page$")
	public void navigate_to_payment_details_page() throws Throwable {
	    
		driver.navigate().to("C:\\BDD Workspace\\AKRAGRAW_SETB\\Driver\\PaymentDetails.html");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		Thread.sleep(1000);
	}

	@Given("^User is on payment page$")
	public void user_is_on_payment_page() throws Throwable {

		objPayment =new PageFactoryPayment(driver);
		driver.get("C:\\BDD Workspace\\AKRAGRAW_SETB\\Driver\\PaymentDetails.html");
	}

	@Then("^check the title of the payment page$")
	public void check_the_title_of_the_payment_page() throws Throwable {
	  
		String title=driver.getTitle();
		if(title.contentEquals("Payment Details")) 
			System.out.println("****** Title Matched **********");
		else 
			System.out.println("****** Title NOT Matched **************");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	}

	@When("^user leaves CardHolderName blank$")
	public void user_leaves_CardHolderName_blank() throws Throwable {
		
		objPayment.setPfCardHolderName(""); Thread.sleep(750);
	}

	@When("^clicks the payment button$")
	public void clicks_the_payment_button() throws Throwable {
		
		objPayment.setPfPayment(); Thread.sleep(750);
	}

	@Then("^display alert meassage for payment$")
	public void display_alert_meassage_for_payment() throws Throwable {
	    
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("*******************" + alertMessage);
	    driver.close();
	}

	@When("^user leaves DebitCardNo blank$")
	public void user_leaves_DebitCardNo_blank() throws Throwable {
		
		objPayment.setPfCardHolderName("Akrati Agrawal"); Thread.sleep(750);
		objPayment.setPfDebit(""); Thread.sleep(750);
		
	}

	@When("^user leaves expirationMonth blank and clicks the submit button$")
	public void user_leaves_expirationMonth_blank_and_clicks_the_submit_button() throws Throwable {
		
		objPayment.setPfCardHolderName("Akrati Agrawal"); Thread.sleep(750);
		objPayment.setPfDebit("7894 5612 3214 6987"); Thread.sleep(750);
		objPayment.setPfCVV("184"); Thread.sleep(750);
		objPayment.setPfMonth(""); Thread.sleep(750);
		objPayment.setPfPayment(); Thread.sleep(750);
	}

	@When("^user leaves expirationYr blank and clicks the submit button$")
	public void user_leaves_expirationYr_blank_and_clicks_the_submit_button() throws Throwable {
		
		objPayment.setPfCardHolderName("Akrati Agrawal"); Thread.sleep(750);
		objPayment.setPfDebit("7894 5612 3214 6987"); Thread.sleep(750);
		objPayment.setPfCVV("184"); Thread.sleep(750);
		objPayment.setPfMonth("08"); Thread.sleep(750);
		objPayment.setPfYear(""); Thread.sleep(750);
		objPayment.setPfPayment(); Thread.sleep(750);
	}

	@When("^user enters all valid data and clicks on the submit button$")
	public void user_enters_all_valid_data_and_clicks_on_the_submit_button() throws Throwable {
	  
		objPayment.setPfCardHolderName("Akrati Agrawal"); Thread.sleep(750);
		objPayment.setPfDebit("7894 5612 3214 6987"); Thread.sleep(750);
		objPayment.setPfCVV("184"); Thread.sleep(750);
		objPayment.setPfMonth("08"); Thread.sleep(750);
		objPayment.setPfYear("2023"); Thread.sleep(750);
		objPayment.setPfPayment(); Thread.sleep(750);
	}

	@After
	public void tearDown()
	{
		driver.quit();
	}

}
