package PageBean;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class PageBeanFactoryClass {

	WebDriver driver;
	//Conference Registration
	@FindBy(name="txtFN")
	@CacheLookup
	WebElement pfFirstName;
	
	@FindBy(name="txtLN")
	@CacheLookup
	WebElement pfLastName;
	
	@FindBy(how=How.ID, using="txtEmail")
	@CacheLookup
	WebElement pfEmail;
	
	@FindBy(how=How.ID, using="txtPhone")
	@CacheLookup
	WebElement pfPhone;
	
	@FindBy(name="size")
	@CacheLookup
	WebElement pfNoOfPeople;
	
	@FindBy(how=How.ID, using="txtAddress1")
	@CacheLookup
	WebElement pfBuilding;
	
	@FindBy(name="Address2")
	@CacheLookup
	WebElement pfArea;
	
	@FindBy(name="city")
	@CacheLookup
	WebElement pfCity;
	
	@FindBy(name="state")
	@CacheLookup
	WebElement pfState;
	
	@FindBy(name="memberStatus")
	@CacheLookup
	List<WebElement> pfMemberStatus;
	
	@FindBy(xpath="html/body/form/table/tbody/tr[14]/td/a")
	@CacheLookup
	WebElement pfNext;
	
	//Initialze
	public PageBeanFactoryClass(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	// Setters
	
	public void setPfFirstName(String sFirstName) {
		pfFirstName.sendKeys(sFirstName);
	}

	public void setPfLastName(String sLastName) {
		pfLastName.sendKeys(sLastName);
	}

	public void setPfEmail(String sEmail) {
		pfEmail.sendKeys(sEmail);
	}

	public void setPfPhone(String sPhone) {
		pfPhone.sendKeys(sPhone);
	}

	public void setPfNoOfPeople(String sNoOfPeople) {
		Select drpPeople= new Select(pfNoOfPeople);
		drpPeople.selectByVisibleText(sNoOfPeople);
	}

	public void setPfBuilding(String sBuilding) {
		pfBuilding.sendKeys(sBuilding);
	}

	public void setPfArea(String sArea) {
		pfArea.sendKeys(sArea);
	}

	public void setPfCity(String sCity) {
		Select drpCity = new Select(pfCity);
		drpCity.selectByVisibleText(sCity);
	}

	public void setPfState(String sState) {
		Select drpState = new Select(pfState);
		drpState.selectByVisibleText(sState);
	}

	public void setPfMemberStatus(String sMemberStatus) {
		boolean flag=false;
		flag=pfMemberStatus.get(0).equals(sMemberStatus);
		if(flag==true)
			pfMemberStatus.get(0).click();
		else
			pfMemberStatus.get(1).click();
	}

	public void setPfNext() {
		pfNext.click();
	}

	

	//Getters
	
	public WebElement getPfLastName() {
		return pfLastName;
	}

	public WebElement getPfEmail() {
		return pfEmail;
	}

	public WebElement getPfPhone() {
		return pfPhone;
	}

	public WebElement getPfNoOfPeople() {
		return pfNoOfPeople;
	}

	public WebElement getPfBuilding() {
		return pfBuilding;
	}

	public WebElement getPfArea() {
		return pfArea;
	}

	public WebElement getPfCity() {
		return pfCity;
	}

	public WebElement getPfState() {
		return pfState;
	}

	public List<WebElement> getPfMemberStatus() {
		return pfMemberStatus;
	}

	public WebElement getPfNext() {
		return pfNext;
	}

	
	
}
