package PageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PageFactoryPayment {

	WebDriver driver;
	
	@FindBy(how=How.ID, using="txtCardholderName")
	@CacheLookup
	WebElement pfCardHolderName;
	
	@FindBy(name="debit")
	@CacheLookup
	WebElement pfDebit;
	
	@FindBy(name="cvv")
	@CacheLookup
	WebElement pfCVV;
	
	@FindBy(how=How.ID, using="txtMonth")
	@CacheLookup
	WebElement pfMonth;
	
	@FindBy(how=How.ID, using="txtYear")
	@CacheLookup
	WebElement pfYear;
	
	@FindBy(xpath="//*[@id='btnPayment']")
	@CacheLookup
	WebElement pfPayment;
	
	
	public PageFactoryPayment(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void setPfCardHolderName(String sCardHolderName) {
		pfCardHolderName.sendKeys(sCardHolderName);
	}

	public void setPfDebit(String sDebit) {
		pfDebit.sendKeys(sDebit);
	}

	public void setPfCVV(String sCVV) {
		pfCVV.sendKeys(sCVV);
	}

	public void setPfMonth(String sMonth) {
		pfMonth.sendKeys(sMonth);
	}

	public void setPfYear(String sYear) {
		pfYear.sendKeys(sYear);
	}

	public void setPfPayment() {
		pfPayment.click();
	}

	public WebElement getPfFirstName() {
		return pfCardHolderName;
	}
	
	public WebElement getPfCardHolderName() {
		return pfCardHolderName;
	}

	public WebElement getPfDebit() {
		return pfDebit;
	}

	public WebElement getPfCVV() {
		return pfCVV;
	}

	public WebElement getPfMonth() {
		return pfMonth;
	}

	public WebElement getPfYear() {
		return pfYear;
	}

	public WebElement getPfPayment() {
		return pfPayment;
	}
	
	
}
