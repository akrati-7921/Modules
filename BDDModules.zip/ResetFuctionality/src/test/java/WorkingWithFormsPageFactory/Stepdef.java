package WorkingWithFormsPageFactory;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageBean.WorkingWithFormsPageFactory;

public class Stepdef {

	WebDriver driver;
	WorkingWithFormsPageFactory objwfpf;
	
	@Given("^User is on form page$")
	public void user_is_on_form_page() throws Throwable {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\AKRAGRAW\\Desktop\\aa\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		objwfpf= new WorkingWithFormsPageFactory(driver);
		driver.get("file:///C:/Users/AKRAGRAW/Desktop/aa/WorkingWithForms.html");
	}

	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
	   
		String title=driver.getTitle();
		if(title.contentEquals("Email Registration Form")) 
			System.out.println("****** Title Matched*******");
		else 
			System.out.println("****** Title NOT Matched*******");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	}

	@When("^user enter all valid data$")
	public void user_enter_all_valid_data() throws Throwable {
	   
		objwfpf.setPfuserName("akrati"); Thread.sleep(1000);
		objwfpf.setPfpwd("akku"); Thread.sleep(1000);
		objwfpf.setPfconPwd("akku"); Thread.sleep(1000);
		objwfpf.setPffirstName("Akrati"); Thread.sleep(1000);
		objwfpf.setPflastName("Agrawal"); Thread.sleep(1000);
		objwfpf.setPfgender("Female"); Thread.sleep(1000);
		objwfpf.setPfdob("01/02/1997"); Thread.sleep(1000);
		objwfpf.setPfemail("akrati@gmail.com"); Thread.sleep(1000);
		objwfpf.setPfaddress("Talawade,Pune"); Thread.sleep(1000);
		objwfpf.setPfcity("Pune"); Thread.sleep(1000);
		objwfpf.setPfphone("7088559555"); Thread.sleep(1000);
		objwfpf.setPfhobbies("Music"); Thread.sleep(1000);
		objwfpf.setPfhobbies("Reading"); Thread.sleep(1000);
		objwfpf.setPfhobbies("Music"); Thread.sleep(1000);
	}

	@When("^clicks the button$")
	public void clicks_the_button() throws Throwable {
	    
		objwfpf.setPfbutton();
	}

	@Then("^display alert msg$")
	public void display_alert_msg() throws Throwable {
	   
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage);
	    driver.close();
	}

	@When("^user leaves UserName blank$")
	public void user_leaves_UserName_blank() throws Throwable {
	   
		objwfpf.setPfuserName(""); Thread.sleep(1000);
	}

	@When("^user leaves Password blank$")
	public void user_leaves_Password_blank() throws Throwable {
	   
		objwfpf.setPfuserName("akrati"); Thread.sleep(1000);
		objwfpf.setPfpwd(""); Thread.sleep(1000);
	}

	@When("^user leaves ConfirmPassword blank$")
	public void user_leaves_ConfirmPassword_blank() throws Throwable {
	    
		objwfpf.setPfuserName("akrati"); Thread.sleep(1000);
		objwfpf.setPfpwd("akku"); Thread.sleep(1000);
		objwfpf.setPfconPwd(""); Thread.sleep(1000);
	}

	@When("^user enters diffrent Password and ConfirmPassword$")
	public void user_enters_diffrent_Password_and_ConfirmPassword() throws Throwable {

		objwfpf.setPfuserName("akrati"); Thread.sleep(1000);
		objwfpf.setPfpwd("akku"); Thread.sleep(1000);
		objwfpf.setPfconPwd("akki"); Thread.sleep(1000);
		Actions action=new Actions(driver);
		action.click(objwfpf.getPffirstName()).perform();
	}

	@When("^user leaves FirstName blank$")
	public void user_leaves_FirstName_blank() throws Throwable {
	   
		objwfpf.setPfuserName("akrati"); Thread.sleep(1000);
		objwfpf.setPfpwd("akku"); Thread.sleep(1000);
		objwfpf.setPfconPwd("akku"); Thread.sleep(1000);
		objwfpf.setPffirstName(""); Thread.sleep(1000);
	}

	@When("^user leaves LastName blank$")
	public void user_leaves_LastName_blank() throws Throwable {
	   
		objwfpf.setPfuserName("akrati"); Thread.sleep(1000);
		objwfpf.setPfpwd("akku"); Thread.sleep(1000);
		objwfpf.setPfconPwd("akku"); Thread.sleep(1000);
		objwfpf.setPffirstName("Akrati"); Thread.sleep(1000);
		objwfpf.setPflastName(""); Thread.sleep(1000);
	}

	@When("^user does not select Gender$")
	public void user_does_not_select_Gender() throws Throwable {
	    
		objwfpf.setPfuserName("akrati"); Thread.sleep(1000);
		objwfpf.setPfpwd("akku"); Thread.sleep(1000);
		objwfpf.setPfconPwd("akku"); Thread.sleep(1000);
		objwfpf.setPffirstName("Akrati"); Thread.sleep(1000);
		objwfpf.setPflastName("Agrawal"); Thread.sleep(1000);
		objwfpf.setPfgender(""); Thread.sleep(1000);
	}

	@When("^user leaves DateOfBirth blank$")
	public void user_leaves_DateOfBirth_blank() throws Throwable {
	    
		objwfpf.setPfuserName("akrati"); Thread.sleep(1000);
		objwfpf.setPfpwd("akku"); Thread.sleep(1000);
		objwfpf.setPfconPwd("akku"); Thread.sleep(1000);
		objwfpf.setPffirstName("Akrati"); Thread.sleep(1000);
		objwfpf.setPflastName("Agrawal"); Thread.sleep(1000);
		objwfpf.setPfgender("Female"); Thread.sleep(1000);
		objwfpf.setPfdob(""); Thread.sleep(1000);
	}

	@When("^user leaves Email blank$")
	public void user_leaves_Email_blank() throws Throwable {

		objwfpf.setPfuserName("akrati"); Thread.sleep(1000);
		objwfpf.setPfpwd("akku"); Thread.sleep(1000);
		objwfpf.setPfconPwd("akku"); Thread.sleep(1000);
		objwfpf.setPffirstName("Akrati"); Thread.sleep(1000);
		objwfpf.setPflastName("Agrawal"); Thread.sleep(1000);
		objwfpf.setPfgender("Female"); Thread.sleep(1000);
		objwfpf.setPfdob("01/02/1997"); Thread.sleep(1000);
		objwfpf.setPfemail(""); Thread.sleep(1000);
	}

	@When("^user leaves Address blank$")
	public void user_leaves_Address_blank() throws Throwable {
	    
		objwfpf.setPfuserName("akrati"); Thread.sleep(1000);
		objwfpf.setPfpwd("akku"); Thread.sleep(1000);
		objwfpf.setPfconPwd("akku"); Thread.sleep(1000);
		objwfpf.setPffirstName("Akrati"); Thread.sleep(1000);
		objwfpf.setPflastName("Agrawal"); Thread.sleep(1000);
		objwfpf.setPfgender("Female"); Thread.sleep(1000);
		objwfpf.setPfdob("01/02/1997"); Thread.sleep(1000);
		objwfpf.setPfemail("akrati@gmail.com"); Thread.sleep(1000);
		objwfpf.setPfaddress(""); Thread.sleep(1000);
	}

	@When("^user leaves Phone blank$")
	public void user_leaves_Phone_blank() throws Throwable {
	    
		objwfpf.setPfuserName("akrati"); Thread.sleep(1000);
		objwfpf.setPfpwd("akku"); Thread.sleep(1000);
		objwfpf.setPfconPwd("akku"); Thread.sleep(1000);
		objwfpf.setPffirstName("Akrati"); Thread.sleep(1000);
		objwfpf.setPflastName("Agrawal"); Thread.sleep(1000);
		objwfpf.setPfgender("Female"); Thread.sleep(1000);
		objwfpf.setPfdob("01/02/1997"); Thread.sleep(1000);
		objwfpf.setPfemail("akrati@gmail.com"); Thread.sleep(1000);
		objwfpf.setPfaddress("Talawade,Pune"); Thread.sleep(1000);
		objwfpf.setPfcity("Pune"); Thread.sleep(1000);
		objwfpf.setPfphone(""); Thread.sleep(1000);
	}

	@When("^user does not select Hobbies$")
	public void user_does_not_select_Hobbies() throws Throwable {
		
		objwfpf.setPfuserName("akrati"); Thread.sleep(1000);
		objwfpf.setPfpwd("akku"); Thread.sleep(1000);
		objwfpf.setPfconPwd("akku"); Thread.sleep(1000);
		objwfpf.setPffirstName("Akrati"); Thread.sleep(1000);
		objwfpf.setPflastName("Agrawal"); Thread.sleep(1000);
		objwfpf.setPfgender("Female"); Thread.sleep(1000);
		objwfpf.setPfdob("01/02/1997"); Thread.sleep(1000);
		objwfpf.setPfemail("akrati@gmail.com"); Thread.sleep(1000);
		objwfpf.setPfaddress("Talawade,Pune"); Thread.sleep(1000);
		objwfpf.setPfcity("Pune"); Thread.sleep(1000);
		objwfpf.setPfphone("7088559555"); Thread.sleep(1000);
		objwfpf.setPfhobbies("Music"); Thread.sleep(1000);
	}
	
}
