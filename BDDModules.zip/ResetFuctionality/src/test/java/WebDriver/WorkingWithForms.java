package WebDriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class WorkingWithForms {

	public static void main(String[] args) {
		
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\AKRAGRAW\\Desktop\\aa\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("file:///C:/Users/AKRAGRAW/Desktop/aa/WorkingWithForms.html");
		
		try {
			driver.findElement(By.id("txtUserName")).sendKeys("Akrati123");
			Thread.sleep(1000);
			
			driver.findElement(By.name("txtPwd")).sendKeys("akki");
			Thread.sleep(1000);
			
			driver.findElement(By.className("Format")).sendKeys("akki");
			Thread.sleep(1000);
			
			driver.findElement(By.cssSelector("input.Format1")).sendKeys("Akrati");
			Thread.sleep(1000);
			
			driver.findElement(By.id("txtLastName")).sendKeys("Akrati");
			Thread.sleep(1000);
			
			driver.findElement(By.cssSelector("input[value='Female']")).click();
			Thread.sleep(1000);
			
			driver.findElement(By.name("DtOB")).sendKeys("02/01/1997");
			Thread.sleep(1000);
			
			driver.findElement(By.name("Email")).sendKeys("akrati@gmail.com");
			Thread.sleep(1000);
			
			driver.findElement(By.id("txtAddress")).sendKeys("Talawade,Pune");
			Thread.sleep(1000);
			
			Select drpCity = new Select(driver.findElement(By.name("City")));
			//drpCity.selectByVisibleText("Mumbai");
			drpCity.selectByIndex(1);
			Thread.sleep(1000);
			
			driver.findElement(By.xpath(".//*[@id='txtPhone']")).sendKeys("7088559555");
			Thread.sleep(1000);
			
			driver.findElement(By.cssSelector("input[value='Reading']")).click();
			driver.findElement(By.cssSelector("input[value='Music']")).click();
			driver.findElement(By.cssSelector("input[value='Movies']")).click();
			Thread.sleep(1000);

			driver.findElement(By.name("reset")).click();
			Thread.sleep(1000);
			
		}
		catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		

	}

}
