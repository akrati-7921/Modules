package HotelBookingAlert;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class BookingAlert {
	
	public static WebDriver driver;
	
	public static void main(String[] args) throws InterruptedException {
		
		Select drpCity;
		Select drpState;
		Select drpGuest;
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\AKRAGRAW\\Desktop\\aa\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("file:///C:/Users/AKRAGRAW/Desktop/aa/hotelbooking.html");
		Thread.sleep(1000);
		
		driver.findElement(By.id("txtFirstName")).sendKeys("");
		Thread.sleep(1000);
		driver.findElement(By.id("btnPayment")).click();
		Thread.sleep(1000);
		alertBox();
		
		driver.findElement(By.id("txtFirstName")).sendKeys("Akrati");
		Thread.sleep(1000);
		driver.findElement(By.id("txtLastName")).sendKeys("");
		Thread.sleep(1000);
		driver.findElement(By.id("btnPayment")).click();
		Thread.sleep(1000);
		alertBox();
		
		driver.findElement(By.id("txtLastName")).sendKeys("Agrawal");
		Thread.sleep(1000);
		driver.findElement(By.id("txtEmail")).sendKeys("");
		Thread.sleep(1000);
		driver.findElement(By.id("btnPayment")).click();
		Thread.sleep(1000);
		alertBox();
		
		driver.findElement(By.id("txtEmail")).sendKeys("akrati@gmail.com");
		Thread.sleep(1000);
		driver.findElement(By.id("txtPhone")).sendKeys("");
		Thread.sleep(1000);
		driver.findElement(By.id("btnPayment")).click();
		Thread.sleep(1000);
		alertBox();
		
		driver.findElement(By.id("txtPhone")).sendKeys("7088559555");
		Thread.sleep(1000);
		driver.findElement(By.xpath("html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")).sendKeys("Tawalde,Pune");
		Thread.sleep(1000);
		drpCity = new Select(driver.findElement(By.name("city")));
		drpCity.selectByVisibleText("Select City");
		driver.findElement(By.id("btnPayment")).click();
		Thread.sleep(1000);
		alertBox();
	
		drpCity = new Select(driver.findElement(By.name("city")));
		drpCity.selectByVisibleText("Pune");
		drpState = new Select(driver.findElement(By.name("state")));
		drpState.selectByVisibleText("Select State");
		driver.findElement(By.id("btnPayment")).click();
		Thread.sleep(1000);
		alertBox();
		
		drpState = new Select(driver.findElement(By.name("state")));
		drpState.selectByVisibleText("Maharashtra");
		drpGuest = new Select(driver.findElement(By.name("persons")));
		drpGuest.selectByVisibleText("2");
		driver.findElement(By.id("btnPayment")).click();
		Thread.sleep(1000);
		alertBox();
		
		driver.findElement(By.id("txtCardholderName")).sendKeys("");
		Thread.sleep(1000);
		driver.findElement(By.id("btnPayment")).click();
		Thread.sleep(1000);
		alertBox();
		
		driver.findElement(By.id("txtCardholderName")).sendKeys("Akrati");
		Thread.sleep(1000);
		driver.findElement(By.id("txtDebit")).sendKeys("");
		Thread.sleep(1000);
		driver.findElement(By.id("btnPayment")).click();
		Thread.sleep(1000);
		alertBox();
		
		driver.findElement(By.id("txtDebit")).sendKeys("7894 5613 7894 4569");
		Thread.sleep(1000);
		driver.findElement(By.id("txtCvv")).sendKeys("");
		Thread.sleep(1000);
		driver.findElement(By.id("btnPayment")).click();
		Thread.sleep(1000);
		alertBox();
		
		driver.findElement(By.id("txtCvv")).sendKeys("194");
		Thread.sleep(1000);
		driver.findElement(By.id("txtMonth")).sendKeys("");
		Thread.sleep(1000);
		driver.findElement(By.id("btnPayment")).click();
		Thread.sleep(1000);
		alertBox();
		
		driver.findElement(By.id("txtMonth")).sendKeys("08");
		Thread.sleep(1000);
		driver.findElement(By.id("txtYear")).sendKeys("");
		Thread.sleep(1000);
		driver.findElement(By.id("btnPayment")).click();
		Thread.sleep(1000);
		alertBox();
			
		driver.findElement(By.id("txtYear")).sendKeys("2023");
		Thread.sleep(1000);
		driver.findElement(By.id("btnPayment")).click();
		Thread.sleep(1000);
		driver.quit();		
		
	}
	
	public static void alertBox() throws InterruptedException
	{
		
		Alert alert=driver.switchTo().alert();
		System.out.println("The alert message is: "+alert.getText());
		alert.accept();
		Thread.sleep(1000);
		
	}

}
