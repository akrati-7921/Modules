package pageBean;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class WorkingWithFormsPageFactory {

	WebDriver driver;
	
	@FindBy(name="txtUName")
	@CacheLookup
	WebElement pfuserName;
	
	@FindBy(name="txtPwd")
	@CacheLookup
	WebElement pfpwd;
	
	@FindBy(how=How.ID, using="txtConfPassword")
	@CacheLookup
	WebElement pfconPwd;
	
	@FindBy(name="txtFN")
	@CacheLookup
	WebElement pffirstName;
	
	@FindBy(name="txtLN")
	@CacheLookup
	WebElement pflastName;
	
	@FindBy(how=How.NAME, using="gender")
	@CacheLookup
	List<WebElement> pfgender;
	
	@FindBy(how=How.ID, using="DOB")
	@CacheLookup
	WebElement pfdob;
	
	@FindBy(xpath="//*[@id='txtEmail']")
	@CacheLookup
	WebElement pfemail;
	
	@FindBy(how=How.ID, using="txtAddress")
	@CacheLookup
	WebElement pfaddress;
	
	@FindBy(how=How.NAME, using="City")
	@CacheLookup
	WebElement pfcity;
	
	@FindBy(how=How.ID, using="txtPhone")
	@CacheLookup
	WebElement pfphone;
	
	@FindBy(how=How.NAME, using="chkHobbies")
	@CacheLookup
	List<WebElement> pfhobbies;
	
	@FindBy(xpath="html/body/form/table/tbody/tr[13]/td/input")
	@CacheLookup
	WebElement pfbutton;
	
	public WorkingWithFormsPageFactory(WebDriver driver) {
		
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	//Setters
	
	public void setPfuserName(String suserName) {
		pfuserName.sendKeys(suserName);
	}

	public void setPfpwd(String spwd) {
		pfpwd.sendKeys(spwd);
	}

	public void setPfconPwd(String sconPwd) {
		pfconPwd.sendKeys(sconPwd);
	}

	public void setPffirstName(String sfirstName) {
		pffirstName.sendKeys(sfirstName);
	}

	public void setPflastName(String slastName) {
		pflastName.sendKeys(slastName);
	}

	public void setPfgender(String sgender) {
		boolean flag=false;
		flag=pfgender.get(0).equals(sgender);
		if(flag==true)
			pfgender.get(0).click();
		else
			pfgender.get(1).click();
	}

	public void setPfdob(String sdob) {
		pfdob.sendKeys(sdob);
	}

	public void setPfemail(String semail) {
		pfemail.sendKeys(semail);
	}

	public void setPfaddress(String saddress) {
		pfaddress.sendKeys(saddress);
	}

	public void setPfcity(String scity) {
		Select drpCity=new Select(pfcity);
		drpCity.selectByVisibleText(scity);
	}

	public void setPfphone(String sphone) {
		pfphone.sendKeys(sphone);
	}

	public void setPfhobbies(String shobbies) {
		for(int i=0;i<pfhobbies.size();i++)
		{
			String str=pfhobbies.get(i).getAttribute("value");
			if(str.equals(shobbies))
				pfhobbies.get(i).click();
		}
	}

	public void setPfbutton() {
		pfbutton.click();
	}

	//Getters
	
	public WebElement getPfuserName() {
		return pfuserName;
	}

	public WebElement getPfpwd() {
		return pfpwd;
	}

	public WebElement getPfconPwd() {
		return pfconPwd;
	}

	public WebElement getPffirstName() {
		return pffirstName;
	}

	public WebElement getPflastName() {
		return pflastName;
	}

	public List<WebElement> getPfgender() {
		return pfgender;
	}

	public WebElement getPfdob() {
		return pfdob;
	}

	public WebElement getPfemail() {
		return pfemail;
	}

	public WebElement getPfaddress() {
		return pfaddress;
	}

	public WebElement getPfcity() {
		return pfcity;
	}

	public WebElement getPfphone() {
		return pfphone;
	}

	public List<WebElement> getPfhobbies() {
		return pfhobbies;
	}

	public WebElement getPfbutton() {
		return pfbutton;
	}	
	
}
